#!/bin/sh

./run.sh monitor > log/monitor.out 2> log/monitor.err &

