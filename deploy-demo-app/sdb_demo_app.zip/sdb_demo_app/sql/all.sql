@app_schema_user.sql
connect app_schema/app_schema
@app_schema_auto.sql
connect / as sysdba
@demo_app_ext.sql
